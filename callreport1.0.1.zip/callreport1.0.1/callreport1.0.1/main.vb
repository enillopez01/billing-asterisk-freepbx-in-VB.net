﻿Imports MySql.Data
Imports MySql.Data.MySqlClient

Public Class main
    Public conn As MySqlConnection
    Public comnd As MySqlCommand
    Public adapt As MySqlDataAdapter
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnFReport.Click
        reportview.Show()
        reportview.Focus()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ConnectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConnectToolStripMenuItem.Click
        btnConnect.PerformClick()
    End Sub

    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportToolStripMenuItem.Click
        btnFReport.PerformClick()
    End Sub

    Private Sub main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        Dim conn As New MySqlConnection
        Dim myConnectionString As String

        myConnectionString = "server=192.168.0.80;Port=3306;database=asteriskcdrdb;uid=freepbx;pwd=;"

        Try
            conn.ConnectionString = myConnectionString
            conn.Open()
            MessageBox.Show("Connection Successful")

        Catch ex As MySql.Data.MySqlClient.MySqlException

            MessageBox.Show("Connection Error" & ex.Message)
        End Try
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show()
    End Sub

    Private Sub SettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SettingsToolStripMenuItem.Click
        conset.Show()
    End Sub
End Class
