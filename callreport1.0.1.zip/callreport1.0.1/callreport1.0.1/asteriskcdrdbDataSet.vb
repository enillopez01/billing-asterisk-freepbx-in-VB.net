﻿Partial Class asteriskcdrdbDataSet
End Class

Namespace asteriskcdrdbDataSetTableAdapters

    Partial Public Class cdrTableAdapter
    End Class
End Namespace
