﻿'Imports MySql.Data
Imports MySql.Data.MySqlClient
Imports Microsoft.Reporting.WinForms
Public Class reportview
    Private Sub reportview_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        DateTimePicker1.Value = Date.Today.AddDays(-1)
        DateTimePicker2.Value = Date.Now()



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        'TODO: This line of code loads data into the 'asteriskcdrdbDataSet.cdr' table. You can move, or remove it, as needed.


        Try
            cdrTableAdapter.FillByLVR(asteriskcdrdbDataSet.cdr, DateTimePicker1.Value, DateTimePicker2.Value, ComboBox1.Text)


        Catch ex As Exception
            MessageBox.Show(ex.Message)

            With ReportViewer1.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\Report1.rdlc"
                .DataSources.Clear()
            End With


        End Try

        ReportViewer1.SetDisplayMode(DisplayMode.PrintLayout)
        ReportViewer1.ZoomMode = ZoomMode.Percent
        ReportViewer1.ZoomPercent = 100
        ReportViewer1.RefreshReport()
        ' ReportViewer1.SetDisplayMode(DisplayMode.PrintLayout)
        'ReportViewer1.ZoomMode = ZoomMode.Percent
        'ReportViewer1.ZoomPercent = 100
        'ReportViewer1.RefreshReport()
        ' With ReportViewer1.LocalReport
        '.ReportPath = Application.StartupPath & "\Reports\Report1.rdlc"
        '.DataSources.Clear()
        'End With


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ReportViewer1.Clear()

    End Sub

    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged

    End Sub
End Class