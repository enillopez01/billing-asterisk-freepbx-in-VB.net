﻿Imports MySql.Data.MySqlClient
Module Module1

    Public conn As New MySqlConnection
    Public comm As New MySqlCommand

    Sub Connection()

        With conn
            Dim conn As New MySqlConnection
            Dim myConnectionString As String

            myConnectionString = "server=192.168.0.80;Port=3306;database=asteriskcdrdb;uid=freepbx;pwd=;"

            Try
                conn.ConnectionString = myConnectionString
                ' conn.Open()
                MessageBox.Show("Connection Successful")

            Catch ex As MySql.Data.MySqlClient.MySqlException

                MessageBox.Show("Connection Error" & ex.Message)
            End Try
        End With
    End Sub


End Module
